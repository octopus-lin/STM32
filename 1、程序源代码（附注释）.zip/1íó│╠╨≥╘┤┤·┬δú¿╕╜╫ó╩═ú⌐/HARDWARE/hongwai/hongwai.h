#ifndef __HONGWAI_H
#define __HONGWAI_H
 
 
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"

#define renti GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12)

 void hongwai(void);
#endif
