#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "oled.h"
#include "usart.h"
#include "exti.h"
#include "timer.h"
#include "HC_SR04.h"
#include "kalman.h"
#include "lsens.h"
#include "adc.h"
#include "hongwai.h"
#include "BEEP.h"
#include "usart2.h"
#include "usart3.h"
#include "myRTC.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "gizwits_product.h"
extern u8  Res3;
extern int timer1; //��ʱ
u16 timer1_set=10;
u16 DS_timer=1; //��ʱʱ��
u16 sonic_dis = 0;//����
u16 sonic_set = 15;//������ֵ
u8 dangwei=0;//��λ 
u8 Res1;//
u8 renflag=0;
u8 yuy_flag=0;//������־
uint8_t MyRTC_flag=0;
int key = 0, flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0, guangmi = 0;
uint8_t sendyuy[6]={0xAA,0x55,0x01,0x02,0x55,0xAA};
char display_buf[16];
uint8_t Time_flag1[3]={8,0,0};
uint8_t DWflag1,DWflag2,DWflag3,DWflag4;
uint8_t DS_flag=0;
void set_data(void);

void display(void)
{
//		OLED_ShowCHinese(35, 0, 0);      //����
//    OLED_ShowCHinese(50, 0, 1);
//    OLED_ShowCHinese(65, 0, 2);
//    OLED_ShowCHinese(80, 0, 3);      
		sprintf(display_buf,"Time:%d%d:%d%d:%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
		OLED_ShowString(1, 0, display_buf,16);
	
    OLED_ShowCHinese(0, 2, 6);
    OLED_ShowCHinese(15, 2, 7);
    OLED_ShowString(30, 2, ":", 16); //ģʽ

    OLED_ShowCHinese(0, 4, 22);
    OLED_ShowCHinese(15, 4, 23);
    OLED_ShowString(30, 4, ":", 16); //����

    OLED_ShowCHinese(64, 4, 30);     //����
    OLED_ShowCHinese(80, 4, 31);
    OLED_ShowString(96, 4, ":", 16);

    OLED_ShowCHinese(0, 6, 24);      //ʱ��
    OLED_ShowCHinese(15, 6, 25);
    OLED_ShowString(30, 6, ":", 16);
    OLED_ShowString(65, 6, "s", 16);
		
		if(flag1 != 1)
		{
		OLED_ShowCHinese(80, 6, 32);     //��λ
    OLED_ShowCHinese(96, 6, 33);
		}
    OLED_ShowString(112, 6, ":", 16);
		
		OLED_ShowNum(40, 4, guangmi, 2, 16);
		OLED_ShowNum(120, 6, dangwei, 1, 16);  //��λ
		OLED_ShowNum(104, 4, sonic_distance / 10, 3, 16);
}
void userInit(void)
{
    memset((uint8_t*)&currentDataPoint, 0, sizeof(dataPoint_t));
    
    /** Warning !!! DataPoint Variables Init , Must Within The Data Range **/ 

    currentDataPoint.valueDS_kai = DS_flag;
    currentDataPoint.valueModel = flag1;
    currentDataPoint.valueLamp_brightness = flag3;
    currentDataPoint.valueIllumination_threshold = timer1_set;
    currentDataPoint.valueTime_hour = Time_flag1[0];
    currentDataPoint.valueTime_min = Time_flag1[1];
    currentDataPoint.valueTime_sec = Time_flag1[2];
    currentDataPoint.valueDistance_threshold = sonic_set;

}
void userHandle(void)
{

		currentDataPoint.valuerecognition = renti?1:0;//Add Sensor Data Collection
    currentDataPoint.valueLux = guangmi;//Add Sensor Data Collection
    currentDataPoint.valuedistance = sonic_dis;//Add Sensor Data Collection
		currentDataPoint.valueIllumination_threshold = timer1_set;
    
}
int main(void)
{
    delay_init();
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    usart3_Init(9600);						//�������ڳ�ʼ��
		usart2_init(9600);
    OLED_Init();                 	//oled��ʼ��
		MyRTC_Init(); //ʱ���ʼ��
    KEY_Init();                   //����
    Lsens_Init();									//����
    
    TIM3_Int_Init(9, 71);         //10us
    EXTIX_Init();
    hc_sr04_init();               //HC_SR04��ʼ��
    TIM4_Int_Init(1000, 72);    //��ʱ
//    TIM2_PWM_Init(899, 0);        //��������
		BEEP_Init();									//������
    BEEP = 0;
    display(); 
		PWM_WS2812B_Init(WS2812B_ARR);
		userInit();		//��ɻ����Ƴ�ʼ��ֵ
	  gizwitsInit();	//����һ�����λ�����
	  gizwitsSetMode(2);
		hongwai();                    //����
    while (1)
    {    

				WS2812B_Reset();
				if(MyRTC_flag==0)
					MyRTC_ReadTime();	//���ô˺�����RTCӲ����·��ʱ��ֵ��ˢ�µ�ȫ������
        sonic_Trig();           //������                                
        sonic_dis = sonic_distance / 10;

				delay_ms(100);
        if(sonic_distance / 10 > sonic_set)  //�����ⱨ��
        {
            BEEP = 0;
						yuy_flag=1;							  
        }
        else if (sonic_distance / 10 <= sonic_set)
        {
            BEEP = 1;
						if(yuy_flag==1)
						{
							yuy_flag=0;
							uart3_send(sendyuy,1);
							uart3_send(sendyuy,6);
						}
        }
        guangmi = Lsens_Get_Val();           //����                   
        key = KEY_Scan(0);
        if (key == 1) //ģʽ�л�
        {
            flag1 += 1;
            if (flag1 > 3)
                flag1 = 0;
						OLED_Clear();	
        }
        if (flag1 == 0)//�Զ�ģʽ                              
        {
						display();
            OLED_ShowCHinese(40, 2, 4);
            OLED_ShowCHinese(56, 2, 5);
            if (renti == 1)
            {
                OLED_ShowCHinese(80+8, 2, 18);//����
                OLED_ShowCHinese(96+8, 2, 19);
                flag2 = 1;
							  renflag=0;
            }
            else if (renti == 0)
            {
                OLED_ShowCHinese(80+8, 2, 20);//����
                OLED_ShowCHinese(96+8, 2, 21);
                flag2 = 0;
            }
            if (flag2 == 1)
            {
								 if (guangmi > 0 && guangmi <= 20)
                {
										if(DWflag4==1)
										{
											DWflag4=0; PWM_WS2812B_GB(8);
										}
										PWM_WS2812B_White(7);
									  dangwei=3;
										DWflag1=1;
                }
                if (guangmi > 20 && guangmi <= 40)
                {    
										if(DWflag1==1)
										{
											DWflag1=0; PWM_WS2812B_GB(8);
										}
										PWM_WS2812B_White(4);
									  dangwei=2;
										DWflag2=1;
                }
                if (guangmi > 40 && guangmi <= 70)
                {
										if(DWflag2==1)
										{
											DWflag2=0; PWM_WS2812B_GB(8);
										}
										PWM_WS2812B_White(1);
									  dangwei=1;
										DWflag3=1;
                }
                if (guangmi > 70)
                {
										if(DWflag3==1)
										{
											DWflag3=0; PWM_WS2812B_GB(8);
										}
										PWM_WS2812B_GB(8);
									  dangwei=0;
										DWflag4=1;
                }
            }
            else if (flag2 == 0)
            {
								if(renflag==1)
								{
									 PWM_WS2812B_GB(8);//�ص�
									 dangwei=0;
								}
            }
						 OLED_ShowNum(40, 6, timer1, 3, 16);
						 if(key == 2) //��������
							{
								set_data();
							}
        }
        if (flag1 == 1)//�ֶ�
        {
						display();
            OLED_ShowCHinese(40, 2, 8);
            OLED_ShowCHinese(56, 2, 9);
            OLED_ShowCHinese(80, 6, 42);     //��ɫ
						OLED_ShowCHinese(96, 6, 43);
            if (key == 2)
            {
               flag3 +=1;
							if(flag3>3)
							{
								flag3=0;
							}
            }
            if (flag3 == 0)
            {    
								PWM_WS2812B_GB(8);
							  dangwei=0;
            }
            else if (flag3 == 1)
            {
								PWM_WS2812B_Orang(8);
							  dangwei=1;
            }
						 else if (flag3 == 2)
            {
							  dangwei=2;
							PWM_WS2812B_White(8);
            }
						 else if (flag3 == 3)
            {
								dangwei=3;
							PWM_WS2812B_Blue(8);
            }
        }
        if (flag1 == 2) //����
        {
						display();
            OLED_ShowCHinese(40, 2, 26);
            OLED_ShowCHinese(56, 2, 27);
            switch (Res3)
            {
            case 1:
                PWM_WS2812B_White(1);
						    dangwei=1;
                break; //����
            case 2:
                PWM_WS2812B_GB(8);
								dangwei=0;
                break; //�ص�
            case 3:
                PWM_WS2812B_White(7);
								dangwei=3;
                break; //�����ƹ�
            case 4:
                PWM_WS2812B_White(4);
								dangwei=2;
                break; //�����ƹ�
            case 5:
                PWM_WS2812B_White(1);
								dangwei=1;
                break; //һ���ƹ�
						case 6:
									
								if (flag3 == 0)
								{    
										PWM_WS2812B_GB(8);
								}
								else if (flag3 == 1)
								{
									PWM_WS2812B_Orang(8);
								}
								 else if (flag3 == 2)
								{
									PWM_WS2812B_White(8);
								}
								 else if (flag3 == 3)
								{
									PWM_WS2812B_Blue(8);
								}
                break; 
            }
        }
				if (flag1 == 3) //��ʱ
        {
					OLED_ShowCHinese(0, 0, 6);
					OLED_ShowCHinese(15, 0, 7);
					OLED_ShowString(30, 0, ":", 16); //ģʽ
					OLED_ShowCHinese(38, 0, 38);      //ʱ��
					OLED_ShowCHinese(54, 0, 39);
					switch (MyRTC_flag)
						{
							case 0:
								OLED_ShowCHinese(0, 6, 42);
							  OLED_ShowCHinese(16, 6, 43);
								OLED_ShowCHinese(72, 6, 38);
							  OLED_ShowCHinese(88, 6, 39);
							  if(DS_flag==1)  OLED_ShowCHinese(104, 6, 44);
								else					  OLED_ShowCHinese(104, 6, 45);	
								OLED_ShowString(120, 6, " ",16);
								OLED_ShowString(32, 6, ":", 16);
								sprintf(display_buf,"%d   ",flag3);
								OLED_ShowString(40, 6, display_buf,16);
								sprintf(display_buf,"Time:%d%d:%d%d:%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
								OLED_ShowString(0, 2, display_buf,16);
								sprintf(display_buf,"Time1:%d%d:%d%d:%d%d",Time_flag1[0]/10,Time_flag1[0]%10,Time_flag1[1]/10,Time_flag1[1]%10,Time_flag1[2]/10,Time_flag1[2]%10);
								OLED_ShowString(0, 4, display_buf,16);
								break;
							case 1:
								sprintf(display_buf,"Time>%d%d:%d%d:%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
								OLED_ShowString(0, 2, display_buf,16);
								break;
							case 2:
								sprintf(display_buf,"Time:%d%d>%d%d:%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
								OLED_ShowString(0, 2, display_buf,16);
								break;
							case 3:
								sprintf(display_buf,"Time:%d%d:%d%d>%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
								OLED_ShowString(0, 2, display_buf,16);
								break;
							case 4:
								sprintf(display_buf,"Time:%d%d:%d%d:%d%d",MyRTC_Time[3]/10,MyRTC_Time[3]%10,MyRTC_Time[4]/10,MyRTC_Time[4]%10,MyRTC_Time[5]/10,MyRTC_Time[5]%10);
								OLED_ShowString(0, 2, display_buf,16);
								sprintf(display_buf,"Time1>%d%d:%d%d:%d%d",Time_flag1[0]/10,Time_flag1[0]%10,Time_flag1[1]/10,Time_flag1[1]%10,Time_flag1[2]/10,Time_flag1[2]%10);
								OLED_ShowString(0, 4, display_buf,16);
								break;
							case 5:
								 sprintf(display_buf,"Time1:%d%d>%d%d:%d%d",Time_flag1[0]/10,Time_flag1[0]%10,Time_flag1[1]/10,Time_flag1[1]%10,Time_flag1[2]/10,Time_flag1[2]%10);
								OLED_ShowString(0, 4, display_buf,16);
								break;
							case 6:
								 sprintf(display_buf,"Time1:%d%d:%d%d>%d%d",Time_flag1[0]/10,Time_flag1[0]%10,Time_flag1[1]/10,Time_flag1[1]%10,Time_flag1[2]/10,Time_flag1[2]%10);
								 OLED_ShowString(0, 4, display_buf,16);
								break;
							case 7:
								sprintf(display_buf,"Time1:%d%d:%d%d:%d%d",Time_flag1[0]/10,Time_flag1[0]%10,Time_flag1[1]/10,Time_flag1[1]%10,Time_flag1[2]/10,Time_flag1[2]%10);
								OLED_ShowString(0, 4, display_buf,16);
								sprintf(display_buf,"%d < ",flag3);
								OLED_ShowString(40, 6, display_buf,16);
								break;
							case 8:
								sprintf(display_buf,"%d   ",flag3);
								OLED_ShowString(40, 6, display_buf,16);
								OLED_ShowString(120, 6, "<",16);
								break;
							default:
								break;
						}
					
						
					if(key == 2)
            {
              MyRTC_flag++;
							if(MyRTC_flag>8)
							{
								MyRTC_flag=0;
								MyRTC_SetTime();	//���ô˺�����ȫ��������ʱ��ֵ��ˢ�µ�RTCӲ����·
							}
            }
					 if(key == 3)
            {
              switch (MyRTC_flag)
							{
								case 1:
									MyRTC_Time[3]++;
									if(MyRTC_Time[3]>23)
										MyRTC_Time[3]=0;
									break;
								case 2:
									MyRTC_Time[4]++;
									if(MyRTC_Time[4]>59)
										MyRTC_Time[4]=0;
									break;
								case 3:
									MyRTC_Time[5]++;
									if(MyRTC_Time[5]>59)
										MyRTC_Time[5]=0;
									break;
								case 4:
									Time_flag1[0]++;
									if(Time_flag1[0]>23)
										Time_flag1[0]=0;
									break;
								case 5:
									Time_flag1[1]++;
									if(Time_flag1[1]>59)
										Time_flag1[1]=0;
									break;
								case 6:
									Time_flag1[2]++;
									if(Time_flag1[2]>59)
										Time_flag1[2]=0;
								break;
								case 7:
									 flag3 +=1;
									 if(flag3>3)
										{
											flag3=0;
										}
										if(flag3 == 0)
										{    
												PWM_WS2812B_GB(8);
										}
										else if (flag3 == 1)
										{
												PWM_WS2812B_Orang(8);
										}
										else if (flag3 == 2)
										{
												PWM_WS2812B_White(8);
										}
										else if (flag3 == 3)
										{
												PWM_WS2812B_Blue(8);
										}
								break;
								case 8:
									 OLED_ShowCHinese(104, 6, 44);DS_flag=1;
								break;
								
								default:
									break;
							}
            }
					 if(key == 4)
            {
              switch (MyRTC_flag)
							{
								case 1:
									if(MyRTC_Time[3]>0)
										MyRTC_Time[3]--;
									break;
								case 2:
									if(MyRTC_Time[4]>0)
										MyRTC_Time[4]--;
									break;
								case 3:
									if(MyRTC_Time[5]>0)
										MyRTC_Time[5]--;
									break;
								case 4:
									if(Time_flag1[0]>0)
										Time_flag1[0]--;
									break;
								case 5:
									if(Time_flag1[1]>0)
										Time_flag1[1]--;
									break;
								case 6:
									if(Time_flag1[2]>0)
										Time_flag1[2]--;
									break;
								case 7:
									 if(flag3>0)
										{
											flag3--;
										}
										if(flag3 == 0)
										{    
												PWM_WS2812B_GB(8);
										}
										else if (flag3 == 1)
										{
												PWM_WS2812B_Orang(8);
										}
										else if (flag3 == 2)
										{
												PWM_WS2812B_White(8);
										}
										else if (flag3 == 3)
										{
												PWM_WS2812B_Blue(8);
										}
								break;
								case 8:
									 OLED_ShowCHinese(104, 6, 45);DS_flag=0;
								break;
	
								default:
									break;
							}
            }
					
					
					if(DS_flag==1)
					{
						if((MyRTC_Time[3]==Time_flag1[0] && MyRTC_Time[4]==Time_flag1[1] && MyRTC_Time[5]==Time_flag1[2]))
						{
							PWM_WS2812B_GB(8);PWM_WS2812B_GB(8);PWM_WS2812B_GB(8);DS_flag=0;
							currentDataPoint.valueDS_kai = DS_flag;
						}
					}	
				}
				userHandle();	//���»��������ݵ�����洢��ֵ
				gizwitsHandle((dataPoint_t *)&currentDataPoint);	//�����ϴ���������
    }
}
//����
void set_data(void)
{
	uint8_t num=0;
	OLED_Clear();	 
	while(1)
	{
		key = KEY_Scan(0);
		if(key == 2) //�˳�
		{
			 num++;
			 if(num>1 )
			 {
				 num=0;
				 OLED_Clear();	
				 display();
				 return;
			 }
		}
		if(key == 3) //��
		{
			if(num==0) sonic_set++; 
			if(num==1) timer1_set++;
			if(num==2) DS_timer++;
		}
		if(key == 4) //��
		{
			if(num==0)
			{
				if(sonic_set>0)
					 sonic_set-- ;
			}
			if(num==1)
			{
				if(timer1_set>0)
					 timer1_set-- ;
			}
			if(num==2)
			{
				if(DS_timer>0)
					 DS_timer-- ;
			}			
		}
		if(num==0)
		{
			OLED_ShowCHinese(0, 2, 34);      //ʱ��
			OLED_ShowCHinese(16, 2, 35);
			OLED_ShowCHinese(32, 2, 30);     //����
			OLED_ShowCHinese(48, 2, 31);
			OLED_ShowString(80, 2, ":", 16);
			OLED_ShowNum(88, 2, sonic_set, 3, 16);
			OLED_ShowString(112, 2, "cm", 16);
		}
		else if (num==1)
		{
			
			OLED_ShowCHinese(0, 2, 36);      //ʱ��
			OLED_ShowCHinese(16, 2, 37);
			OLED_ShowCHinese(32, 2, 24);      //ʱ��
			OLED_ShowCHinese(48, 2, 25);
			OLED_ShowString(80, 2, ":", 16);
			OLED_ShowNum(88, 2, timer1_set, 3, 16);
			OLED_ShowString(112, 2, "s ", 16);
		}
//		else if (num==2)
//		{
//			
//			OLED_ShowCHinese(0, 2, 38);      //ʱ��
//			OLED_ShowCHinese(16, 2, 39);
//			OLED_ShowCHinese(32, 2, 24);      //ʱ��
//			OLED_ShowCHinese(48, 2, 25);
//			OLED_ShowString(70, 2, ":", 16);
//			OLED_ShowNum(78, 2, DS_timer, 3, 16);
//			OLED_ShowString(102, 2, "min", 16);
//		}
	}
}
